#!/usr/bin/env bash
# Publica un usuario y una orden en los topics Kafka `users` y `orders` cada 15 segundos
# Uso: bash publish_to_kafka_loop.sh

set -euo pipefail
WORKDIR="$(cd "$(dirname "$0")" && pwd)"
COMPOSE_FILE="$WORKDIR/docker-compose-full.yml"
LOGFILE="$WORKDIR/publish_kafka.log"

echo "Starting Kafka publisher loop (logs -> $LOGFILE)"
echo "---- $(date -u +%Y-%m-%dT%H:%M:%SZ) Kafka publisher started ----" >> "$LOGFILE"

while true; do
  TS=$(date +%s)
  NAME="TestUser-${TS}"
  EMAIL="test.${TS}@example.com"
  AGE=$((RANDOM % 50 + 18))  # Random age 18-67
  CITY="City-${TS}"
  PRODUCT="TestProduct-${TS}"
  AMOUNT=$(awk -v seed="$TS" 'BEGIN { srand(seed); printf("%.2f", (rand()*200)+1) }')

  # Construir JSON simples (evitar dependencias externas)
  USER_JSON=$(printf '{"id":%s,"name":"%s","email":"%s","age":%s,"city":"%s","created_at":"%s"}' "$TS" "$NAME" "$EMAIL" "$AGE" "$CITY" "$(date -u +%Y-%m-%dT%H:%M:%SZ)")
  ORDER_JSON=$(printf '{"id":%s,"user_id":%s,"product":"%s","amount":%s,"status":"pending","created_at":"%s"}' "$((TS+1))" "$TS" "$PRODUCT" "$AMOUNT" "$(date -u +%Y-%m-%dT%H:%M:%SZ)")

  echo "[$(date +%T)] Publishing user: $NAME / $EMAIL" >> "$LOGFILE"
  printf '%s\n' "$USER_JSON" | docker-compose -f "$COMPOSE_FILE" exec -T kafka kafka-console-producer --bootstrap-server localhost:29092 --topic users-topic >> "$LOGFILE" 2>&1 || {
    echo "[$(date +%T)] Error publishing user" >> "$LOGFILE"
  }

  echo "[$(date +%T)] Publishing order for user_ts $TS: $PRODUCT ($AMOUNT)" >> "$LOGFILE"
  printf '%s\n' "$ORDER_JSON" | docker-compose -f "$COMPOSE_FILE" exec -T kafka kafka-console-producer --bootstrap-server localhost:29092 --topic orders-topic >> "$LOGFILE" 2>&1 || {
    echo "[$(date +%T)] Error publishing order" >> "$LOGFILE"
  }

  echo "[$(date +%T)] Published user and order (if no errors)" >> "$LOGFILE"
  sleep 15
done
