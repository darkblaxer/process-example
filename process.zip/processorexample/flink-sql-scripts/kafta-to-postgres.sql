-- ============================================================================
-- FLINK SQL SCRIPT: Kafka to PostgreSQL Pipeline (Real-time Streaming)
-- ============================================================================
-- Descripción:
--   Este script procesa eventos en TIEMPO REAL desde Kafka.
--   Lee los tópicos de usuarios y órdenes, realiza un JOIN y agregación,
--   y guarda los resultados procesados en PostgreSQL para análisis.
--
-- Flujo de datos:
--   Kafka (users-topic + orders-topic) → Flink (JOIN + Agregación) → PostgreSQL (flink_results)
--
-- Características:
--   - Procesamiento streaming en tiempo real
--   - WATERMARK para manejo de eventos tardíos (5 segundos)
--   - Formato JSON para serialización de eventos
--   - Auto offset reset en earliest para no perder datos
--
-- Casos de uso:
--   - Monitoreo en tiempo real de órdenes
--   - Dashboards actualizados continuamente
--   - Alertas basadas en patrones de compra
-- ============================================================================

-- Registrar conector Kafka como source
CREATE TABLE kafka_users (
    id INT,
    name STRING,
    email STRING,
    age INT,
    city STRING,
    created_at STRING
) WITH (
    'connector' = 'kafka',
    'topic' = 'users-topic',
    'properties.bootstrap.servers' = 'kafka:29092',
    'properties.group.id' = 'flink-group-4',
    'properties.auto.offset.reset' = 'earliest',
    'scan.startup.mode' = 'group-offsets',
    'format' = 'json'
);

-- Crear tabla source para órdenes desde Kafka
-- El WATERMARK permite manejar eventos que llegan fuera de orden (hasta 5 segundos de retraso)
CREATE TABLE kafka_orders (
    id INT,
    user_id INT,
    product STRING,
    amount DECIMAL(10, 2),
    status STRING,
    created_at STRING
) WITH (
    'connector' = 'kafka',
    'topic' = 'orders-topic',
    'properties.bootstrap.servers' = 'kafka:29092',
    'properties.group.id' = 'flink-group-4',
    'properties.auto.offset.reset' = 'earliest',
    'scan.startup.mode' = 'group-offsets',
    'format' = 'json'
);

-- Crear tabla de salida para resultados procesados en PostgreSQL
CREATE TABLE postgres_results (
    id INT,
    name STRING,
    email STRING,
    age INT,
    city STRING,
    product_count INT,
    total_spent DECIMAL(10, 2),
    created_at TIMESTAMP(3),
    PRIMARY KEY (id) NOT ENFORCED
) WITH (
    'connector' = 'jdbc',
    'url' = 'jdbc:postgresql://postgres:5432/nifi_db',
    'driver' = 'org.postgresql.Driver',
    'username' = 'nifi',
    'password' = 'nifi123',
    'table-name' = 'flink_results',
    'sink.buffer-flush.max-rows' = '100',
    'sink.buffer-flush.interval' = '5000'
);

-- ============================================================================
-- TRANSFORMACIÓN Y CARGA EN TIEMPO REAL
-- ============================================================================
-- Esta query realiza las siguientes operaciones:
-- 1. JOIN entre usuarios (u) de Kafka y órdenes (o) de Kafka utilizando user_id
-- 2. LEFT JOIN para incluir usuarios sin órdenes
-- 3. Agrupación por usuario (u.id, nombre, email, etc.)
-- 4. Conteo de órdenes en el stream por usuario (COUNT)
-- 5. Suma del total gastado en el stream por usuario (SUM del monto)
-- 6. Timestamp actual para auditoría
-- 7. Buffer flush automático cada 100 filas o 5 segundos a PostgreSQL
-- NOTA: Este es un job de streaming continuo que se ejecuta indefinidamente
INSERT INTO postgres_results
SELECT 
    u.id,
    u.name,
    u.email,
    u.age,
    u.city,
    CAST(COUNT(o.id) AS INT) as product_count,
    CAST(SUM(o.amount) AS DECIMAL(10, 2)) as total_spent,
    CURRENT_TIMESTAMP as created_at
FROM kafka_users u
LEFT JOIN kafka_orders o ON u.id = o.user_id
GROUP BY u.id, u.name, u.email, u.age, u.city;
